SubstituteJelly is a mod that watches for the spousal jealousy event, and negates the 
friendship penalty when it occurs.

If you have the companion content pack "JellyLines" installed, the jealousy line will be 
replaced with an offhand remark about "I heard you met X today. I hope they're doing well."

If you do not have JellyLines installed, your spouse's dialogue will simply be reset to
whatever their normal dialogue would be in the conditions that the jealousy even triggered.


SubstituteJelly also adds the SMAPI command "player_getsf" which displays the exact 
friendship of the farmer's spouse.